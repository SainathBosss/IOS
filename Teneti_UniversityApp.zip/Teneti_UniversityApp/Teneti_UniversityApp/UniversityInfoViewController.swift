//
//  UniversityInfoViewController.swift
//  Teneti_UniversityApp
//
//  Created by Teneti,Sainath R on 4/20/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {

    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    var sch = UniversityList()
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = sch.collegeName
        universityImageViewOutlet.image = UIImage(named: sch.collegeImage)
        universityInfoOutlet.isHidden = true
    }
    
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text = sch.collegeInfo
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
