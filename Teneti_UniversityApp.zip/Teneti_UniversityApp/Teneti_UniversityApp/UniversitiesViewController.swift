//
//  ViewController.swift
//  Teneti_UniversityApp
//
//  Created by Teneti,Sainath R on 4/20/23.
//

import UIKit

let sch = school
class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sch.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = sch[indexPath.row].domain
        return cell
    }
    

    @IBOutlet weak var universitiesTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let identifier = segue.identifier
        if identifier == "listsSegue" {
            let dest  = segue.destination as! UniversityListViewController
            dest.schol = sch[(universitiesTableView.indexPathForSelectedRow?.row)!]
        }
    }

}

