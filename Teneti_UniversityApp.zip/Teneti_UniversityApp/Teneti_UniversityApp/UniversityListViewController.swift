//
//  UniversityListViewController.swift
//  Teneti_UniversityApp
//
//  Created by Teneti,Sainath R on 4/20/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var schol = Universities()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return schol.UniversityList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var c = universityListTableView.dequeueReusableCell(withIdentifier:  "listCell", for: indexPath)
        c.textLabel?.text = schol.UniversityList[indexPath.row].collegeName
        return c
    }
    

    @IBOutlet weak var universityListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
        self.title = schol.domain
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let identifier = segue.identifier
        if identifier == "universityInfoSegue"{
            let dest = segue.destination as! UniversityInfoViewController
            dest.sch = schol.UniversityList[(universityListTableView.indexPathForSelectedRow?.row)!]
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
