//
//  ViewController.swift
//  Teneti_Exam02
//
//  Created by Teneti,Sainath R on 4/11/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var courseIDOL: UITextField!
    @IBOutlet weak var studentIDOL: UITextField!
    @IBOutlet weak var displayStatusOL: UILabel!
    @IBOutlet weak var imageOL: UIImageView!
    @IBOutlet weak var courseCheckBtn: UIButton!
    
    @IBOutlet weak var enrollCourseBtn: UIButton!
    
    var courseFound = CourseDetails()
        
        //to check whether user is student/guest
        //Initially isStudent is false that means user is a guest
        var isCourseDetails = false
        
        //Array of type Student, we imported it from the 'Student' file
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        if(courseIDOL.text != "" && studentIDOL.text != ""){
            courseCheckBtn.isEnabled = true
        }
        else{
            courseCheckBtn.isEnabled = false
        }
    }

    @IBAction func courceCheckBtnClicked(_ sender: Any) {
        //Read text From Text fields
        var courseID = courseIDOL.text!
        var studentID = studentIDOL.text!
        for CourseDetails in CoursesArray {
                    if courseID == CourseDetails.courseID{
                        enrollCourseBtn.isHidden = false
                        
                    }
                }
        
        
        
    }
    
    @IBAction func enrollCourseBtnOL(_ sender: UIButton) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "courseSegue"{
                //Create a destination of type studentInfoViewController
                let destination = segue.destination as! courseViewController
                
            if isCourseDetails {
                            destination.courseObj = courseFound
            }
                else{
                            //if the given sid is not in the array, then the student is a guest!!
                            //we set the boolean in the destination as true!!
                            print("Course Id not found")
            }
    }
}
}
