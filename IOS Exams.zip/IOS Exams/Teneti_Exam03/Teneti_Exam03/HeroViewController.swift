//
//  ViewController.swift
//  Teneti_Exam03
//
//  Created by Teneti,Sainath R on 4/27/23.
//

import UIKit



class HeroViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return heros.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = myTableOL.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        //populate the cell
        myCell.textLabel?.text = heros[indexPath.row].hName
        //Return the cell
        return myCell
    }
    
var heros = heroArray
    
    @IBOutlet weak var myTableOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTableOL.delegate = self
        myTableOL.dataSource = self
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if transition == "detailsSegue"{
            let destination = segue.destination as! AnimiViewController
            
            destination.spr = heros[(myTableOL.indexPathForSelectedRow?.row)!]
        }
    }

}

