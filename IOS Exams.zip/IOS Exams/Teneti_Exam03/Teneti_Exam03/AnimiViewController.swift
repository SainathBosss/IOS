//
//  AnimiViewController.swift
//  Teneti_Exam03
//
//  Created by Teneti,Sainath R on 4/27/23.
//

import UIKit

class AnimiViewController: UIViewController {

    var spr : Heros?
    @IBOutlet weak var labelViewOL: UILabel!
    
    @IBOutlet weak var imageViewOL: UIImageView!
    override func viewDidLoad() {
           super.viewDidLoad()
           labelViewOL.text = spr?.hName
         //  imageViewOL.image = UIImage(named: "\((spr?.images)!)")
        // Do any additional setup after loading the view.
    }
    @IBAction func btnClickOL(_ sender: Any) {
            //Image should zoom in and get back to normal positon with specific time duration
            var width = imageViewOL.frame.width
            width += 40
            
            var height = imageViewOL.frame.height
            height += 40
            
            var x = imageViewOL.frame.origin.x-20
            
            var y = imageViewOL.frame.origin.y-20
            
            var largeFrame = CGRect(x : x, y : y, width: width, height: height)
            
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {self.imageViewOL.frame = largeFrame})
        }

    
    

    /*
    // MARK: - Navigation
     
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
