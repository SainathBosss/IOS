//
//  Heros.swift
//  Teneti_Exam03
//
//  Created by Teneti,Sainath R on 4/27/23.
//

import Foundation

struct Heros{
    var hName = ""
    var images = ""
}

var h1 =  Heros(hName: "Super Man", images: "img1")

var h2 =  Heros(hName: "Bat Man", images: "img2")

var h3 =  Heros(hName: "Iron Man", images: "img3")

var h4 =  Heros(hName: "Sipder Man", images: "img4")

var h5 =  Heros(hName: "Hulk", images: "img5")

var h6 =  Heros(hName: "Thor", images: "img6")

var heroArray = [h1,h2,h3,h4,h5,h6]
