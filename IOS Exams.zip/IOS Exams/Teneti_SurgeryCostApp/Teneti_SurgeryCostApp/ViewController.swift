//
//  ViewController.swift
//  Teneti_SurgeryCostApp
//
//  Created by Teneti,Sainath R on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    var heartTax = 11.75
    var brainTax = 13.5
    var kneeTax = 6.25
    
    
    @IBOutlet weak var nameOL: UITextField!
    
    @IBOutlet weak var surgeryOL: UITextField!
    
    @IBOutlet weak var costOL: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonCalc(_ sender: Any) {
        //Read the input
        let name = nameOL.text!
        let surgeryType = surgeryOL.text!
        let cost = Double(costOL.text!)
        //display the output in display label & Images in imgae view
        if (surgeryType == "Heart" && cost == 3000.5){
            let totalCost =  Double((cost!)*(1 + 11.75/100)) - Double(500)
            let tCost = round(totalCost*100) / 100.0
            displayLabel.text = "\(name): \rTotal cost for Heart🫀 srgery is $\(tCost) "
            imageViewOL.image = UIImage(named: "Heart1")
        }
        else if (surgeryType == "Brain"){
            let totalCost =  Double((cost!)*(1 + 13.5/100)) - Double(750)
            let tCost = round(totalCost*100) / 100.0
            displayLabel.text = "\(name): \rTotal cost for Brain🧠 srgery is $\(tCost) "
            imageViewOL.image = UIImage(named: "Brain1")
        }
        else if (surgeryType == "Knee replacement" && cost == 1500.75){
            let totalCost =  round(Double((cost!)*(1 + 6.25/100)) - Double(350))
            let tCost = round(totalCost*100) / 100.0
            displayLabel.text = "\(name): \rTotal cost for Knee replcement🦿 surgery is $\(tCost) "
            imageViewOL.image = UIImage(named: "Knee1")
        }
        else{
            displayLabel.text = "Enter all deatails"
            imageViewOL.image = UIImage(named: "noResults1")
        }
    }
    
}

