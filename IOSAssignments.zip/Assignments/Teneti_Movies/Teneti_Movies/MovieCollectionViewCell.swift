//
//  MovieCollectionViewCell.swift
//  Teneti_Movies
//
//  Created by Teneti,Sainath R on 4/25/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageOL: UIImageView!
    func assignMovies(movie: Movie){
      imageOL.image = movie.image
    }
}
