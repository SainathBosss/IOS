//
//  ViewController.swift
//  Teneti_Movies
//
//  Created by Teneti,Sainath R on 4/25/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return x.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var tv = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        
        tv.textLabel?.text = x[indexPath.row].category
        
        return tv
    }
    

    
    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        genreTableView.delegate = self
        genreTableView.dataSource = self
        self.title = "Movies App"
    }


    let x = genres
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let destination = segue.destination as! MoviesViewController
            destination.mv = x[(genreTableView.indexPathForSelectedRow?.row)!]
            
        }
    }
}

