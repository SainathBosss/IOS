//
//  MoviesViewController.swift
//  Teneti_Movies
//
//  Created by Teneti,Sainath R on 4/25/23.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (mv?.movies.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let tv = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        tv.assignMovies(movie: (mv?.movies[indexPath.row])!)
        return tv
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        movieNameLabel.text = "Movie Name : \((mv?.movies[indexPath.row].title)!)"
            
        movieRatingLabel.text = "Movie Rating : \((mv?.movies[indexPath.row].movieRating)!)"
            
        movieBoxOfficeLabel.text = "Box Office Collection : \((mv?.movies[indexPath.row].boxOffice)!)"
        movieYearLabel.text = "Movie Released Year : \((mv?.movies[indexPath.row].releasedYear)!)"
        moviePlotLabel.text = "Plot : \((mv?.movies[indexPath.row].moviePlot)!)"
        movieCastLabel.text = "Cast : \((mv?.movies[indexPath.row].cast.joined(separator: ", "))!)"
        
        
    }
    
    

    var mv:Genre?
    @IBOutlet weak var movieCollectionView: UICollectionView!
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var movieRatingLabel: UILabel!
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    @IBOutlet weak var movieYearLabel: UILabel!
    @IBOutlet weak var moviePlotLabel: UILabel!
    @IBOutlet weak var movieCastLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        movieCollectionView.delegate = self
        movieCollectionView.dataSource  = self
        self.title = "\((mv?.category)!)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
