//
//  MovieData.swift
//  Teneti_Movies
//
//  Created by Teneti,Sainath R on 4/28/23.
//

import Foundation

import UIKit

struct Movie {
var title = " "
    var image:UIImage?
    var releasedYear = "String"
    var movieRating = ""
    var boxOffice = ""
    var moviePlot = ""
    var cast: [String] = []
}

struct Genre {
    var category = ""
    var movies:[Movie] = []
}



let list1 = Genre(category: "Comedy", movies: [Movie(title: "Das Ka Dhamki", image: UIImage(named: "comedy")!, releasedYear: "2023", movieRating: "2.5", boxOffice: "8.9Cr", moviePlot: "Das Ka Dhamki is a comedy thriller movie written by Prasanna Kumar Bezawada and directed by Vishwak Sen. ", cast: ["Vishwak Sen","Nivetha Pethuraj"]),
    Movie(title: "Nede Vidudala", image: UIImage(named: "comedy1")!, releasedYear: "2023", movieRating: "3.5", boxOffice: "78k", moviePlot: "The protagonist decides to crack down on the world of online film piracy, and must face the mafia behind it ", cast: ["Asif Ali Khan","Mouryani"]),
    Movie(title: "Premadesam", image: UIImage(named: "comedy2")!, releasedYear: "2023", movieRating: "4.5", boxOffice: "100M", moviePlot: "Premadesam (2023) photos, including production stills, premiere photos and other event photos, publicity photos, behind-the-scenes, and more.", cast: ["Thrigun","Megha Akash"]),
    Movie(title: "Dhamaka", image: UIImage(named: "comedy3")!, releasedYear: "2022", movieRating: "5.5", boxOffice: "100M", moviePlot: "Dhamaka (transl. Blast) is a 2021 Indian Hindi-language thriller film[4] written and directed by Ram Madhvani. An official remake of the 2013 film", cast: ["Ravi Teja","Sreeleela"]),
    Movie(title: "18 Pages", image: UIImage(named: "comedy4")!, releasedYear: "2022", movieRating: "6.4", boxOffice: "500M", moviePlot: "18 Pages is a 2022 Indian Telugu-language romantic thriller film written by Sukumar and directed by Palnati Surya Pratap.", cast: ["Nikhil Siddhartha","Anupama"])])

let list2 = Genre(category: "Thriller", movies: [Movie(title: "Kantara", image: UIImage(named: "acti")!, releasedYear: "2022", movieRating: "8.3", boxOffice: "40Cr", moviePlot: "When greed paves the way for betrayal, scheming and murder, a young tribal reluctantly dons the traditions of his ancestors to seek justice.", cast: ["sapthami","Rishab"]),
    Movie(title: "Virupaksha", image: UIImage(named: "action1")!, releasedYear: "2023", movieRating: "8.1", boxOffice: "30m", moviePlot: "Mysterious deaths occur in a village due to an unknown person's occult practices. The whole town is afraid, and the problems continue as they search for the one responsible.", cast: ["Dhermtej","Samyuktha"]),
    Movie(title: "War", image: UIImage(named: "action2")!, releasedYear: "2019", movieRating: "7.1", boxOffice: "35Cr", moviePlot: "An Indian soldier chases after his mentor who has gone rogue following an unexpected kill.", cast: ["Hrithik","Vaani"]),
    Movie(title: "The Legend ", image: UIImage(named: "action3")!, releasedYear: "2022", movieRating: "9.9", boxOffice: "40.1Cr", moviePlot: "Saravanan, a foreign-educated researcher returns to his native place in India. His family runs colleges and hospitals. He crosses swords with a filthy-rich medical mafia with only commercial intentions.", cast: ["Ram Charan","Alia"]),
   Movie(title: "Pushpa: The Rise - Part 1", image: UIImage(named: "action4")!, releasedYear: "2022", movieRating: "7.6", boxOffice: "15Cr", moviePlot: "A labourer rises through the ranks of a red sandal smuggling syndicate, making some powerful enemies in the process.", cast: ["Allu Arjun","Rashika"])
                                                 ])

let list3 = Genre(category: "Action", movies: [Movie(title: "NTR 30", image: UIImage(named: "act")!, releasedYear: "2023", movieRating: "7.7", boxOffice: "70Cr", moviePlot: "Mysterious deaths occur in a village due to an unknown person's occult practices. The whole town is afraid, and the problems continue as they search for the one responsible.", cast: ["Jr. Ntr", "Janhvi Kapoor"]),
    Movie(title: "Agni Varsham", image: UIImage(named: "act1")!, releasedYear: "2014", movieRating: "7.1", boxOffice: "12.0Cr", moviePlot: "ohn Form (Ward Horton) thinks he's found the perfect gift for his expectant wife, Mia (Annabelle Wallis) : a vintage doll in a beautiful white dress.", cast: ["Nagarjuna Akkineni", "Raveena Tandon"]),
    Movie(title: "SSMB 28", image: UIImage(named: "act2")!, releasedYear: "2013", movieRating: "6.3", boxOffice: "104Cr", moviePlot: "n 1970, paranormal investigators and demonologists Lorraine (Vera Farmiga) and Ed (Patrick Wilson) Warren are summoned to the home of Carolyn (Lili Taylor) and Roger (Ron Livingston) Perron.", cast: [" Mahesh Babu", "Pooja Hegde"]),
    Movie(title: "Kalakaar", image: UIImage(named: "act3")!, releasedYear: "1981", movieRating: "9.8", boxOffice: "100Cr", moviePlot: "Ashley Williams (Bruce Campbell), his girlfriend and three pals hike into the woods to a cabin for a fun night away.", cast: ["Rohit,"]),
    Movie(title: "Police Vari Hecharika", image: UIImage(named: "act4")!, releasedYear: "2022", movieRating: "7.6", boxOffice: "150Cr", moviePlot: "With the help of her meek and cowardly neighbor Gopi, single mother Neelam struggles to save her possessed daughter from the clutches of an evil force.", cast: ["Naga Shourya,"])])

let genres = [list1, list2, list3]
