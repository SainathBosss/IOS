//
//  ViewController.swift
//  Teneti_UniversityApp
//
//  Created by Teneti,Sainath R on 4/20/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

