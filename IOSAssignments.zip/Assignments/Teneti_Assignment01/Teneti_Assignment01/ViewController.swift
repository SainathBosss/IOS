//
//  ViewController.swift
//  Teneti_Assignment01
//
//  Created by Teneti,Sainath R on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
//connection givwn for all text boxes and labels
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
     
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var detailsLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //Actions provided for all labels
    @IBAction func SubmitButton(_ sender: UIButton) {
        //To read the text Input and store it
        //assigning variables
        var first = firstNameOutlet.text!
        var last = lastNameOutlet.text!
        var dob = yearOutlet.text!
        //code to calculate age
        let year = Calendar.current.component(.year, from: Date())
        //Perform Sting Interpollation....Assign the data display label
        var age = year - (Int(dob) ?? 0)
        
            detailsLabel.text = "Details"
            
            fullNameLabel.text = "Full Name : \(last) \(first)"
            
            initialsLabel.text = "Initials : \(last.first!) \(first.first!)"
            
            ageLabel.text = "Age : \(age)"
        
        }
        //Action is provided for reset button
        @IBAction func ResetButton(_ sender: Any) {
        
            detailsLabel.text = ""
            fullNameLabel.text = ""
            initialsLabel.text = ""
            ageLabel.text = ""
            firstNameOutlet.text = ""
            lastNameOutlet.text = ""
            yearOutlet.text = ""
    
        }
}

