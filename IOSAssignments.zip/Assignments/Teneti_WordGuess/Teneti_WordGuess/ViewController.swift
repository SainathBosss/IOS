//
//  ViewController.swift
//  Teneti_WordGuess
//
//  Created by Teneti,Sainath R on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    let words = [["Tulasi","Medicine Plant","Plant"],
                 ["Swift","Programming Language","Swift"],
                 ["Jerry","Cartoon Character","Jerry"],
                 ["Tiger","Wild Animal","Tiger"],
                 ["iPhone","Mobile Phone","iPhone"]]
        var wrd = ""
        var cu = 0
        var ltrs = ""
        var maxNumOfWrongGuesses = 10
        var maximum = 0

        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            
            // Do any additional setup after loading the view.
                   wordGuessLBL.isEnabled = false
                   
                   wrd = words[cu][0]
                   
                 hintLabel.text = "Hint: "+words[cu][1]
                   
            updateUnderScore();
                   
                statusLabel.isHidden = true
                   
                totalWordsLabel.text! += "\(words.count)"
                   
                   
               }
        
        
        
        @IBOutlet weak var wordsGuessedLabel: UILabel!
        
        @IBOutlet weak var wordsRemainingLabel: UILabel!
        
        
        @IBOutlet weak var totalWordsLabel: UILabel!
        
        
        @IBOutlet weak var userGuessLabel: UILabel!
        
        
        @IBOutlet weak var guessLetterField: UITextField!
        
       
       
    @IBAction func guessField(_ sender: UITextField) {
        var t = guessLetterField.text!
               
               t = String(t.last ?? " ").trimmingCharacters(in: .whitespaces)
               
               guessLetterField.text = t
               
               if t.isEmpty{
                   wordGuessLBL.isEnabled = false
               }
               else{
                   wordGuessLBL.isEnabled = true
               }
    }
    
        
        @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
            let letter = guessLetterField.text!
              
            maximum+=1
                 //Replace the guessed letter if the letter is part of the word.
            hintLabel.isHidden = false
            hintLabel.isEnabled = true
            ltrs = ltrs + letter
            guessCountLabel.isHidden =  false
            guessCountLabel.isEnabled = true
                  var revealedWord = ""
                 for l in wrd{
                     if ltrs.contains(l.uppercased()){
                         revealedWord += "\(l.uppercased())"
                     }
                     else{
                         revealedWord += "_ "
                     }
                 }
            guessCountLabel.text = "You have made \(maximum) guesses"
                 //Assigning the word to displaylabel after a guess
                 userGuessLabel.text = revealedWord
                 guessLetterField.text = ""
                 
                 //If the word is guessed correctly, we are enabling play again button and disabling the check button.
                 if userGuessLabel.text!.contains("_") == false{
                     playAgainLBL.isHidden = false;
                     displayImage.image = UIImage(named: words[cu][2])
                     guessCountLabel.text = "Wow! You have made \(maximum) guesses to guess the word!"
                     cu+=1
                     let remaining = words.count - cu
                     wordsGuessedLabel.text = "Total number of words guessed successfully: \(cu)"
                     wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
                     wordGuessLBL.isEnabled = false;
                     cu-=1
                 }
            
            if(maximum == maxNumOfWrongGuesses){
                guessCountLabel.text = "You have used all the available guesses, Please play again"
                wordGuessLBL.isEnabled = false
                hintLabel.isHidden = true
                cu-=1
                playAgainLBL.isHidden = false
                playAgainLBL.isEnabled = true
                
            }
            wordGuessLBL.isEnabled = false
           
        }
        
        @IBOutlet weak var hintLabel: UILabel!
        
        @IBOutlet weak var guessCountLabel: UILabel!
        
        @IBOutlet weak var statusLabel: UILabel!
        
        
        @IBAction func playAgainButtonPressed(_ sender: UIButton) {
            
            maximum = 0
            cu+=1
            let remaining = words.count - cu
            userGuessLabel.isHidden = false
            userGuessLabel.isEnabled=true
            statusLabel.isHidden = true
            playAgainLBL.isEnabled = true
            displayImage.image = UIImage()
            ltrs = ""
            hintLabel.isHidden = false
            guessCountLabel.text = "You have made \(maximum) guesses"
            wordsGuessedLabel.text = "Total number of words guessed successfully: \(cu)"
            wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
            
            
            if cu==words.count{
                statusLabel.isHidden = false
                statusLabel.text = "Congratulations, You are done, Please start over again"
              //  displayImage.image
                guessCountLabel.isHidden = true
                displayImage.image = UIImage(named: "AllDone")
                cu = -1
                userGuessLabel.isHidden = true
                hintLabel.isHidden = true
              //  let remaining = words.count - cnt
                wordsGuessedLabel.text = "Total number of words guessed successfully: 0"
                wordsRemainingLabel.text = "Total number of words remaining in game: \(words.count)"
                
            }
            else{
                wrd = words[cu][0]
                
                hintLabel.text = "Hint: " + words[cu][1]
                
                wordGuessLBL.isEnabled = true
                
                updateUnderScore()
                
                playAgainLBL.isHidden = true
            }
        }
        
        @IBOutlet weak var displayImage: UIImageView!
        
        
        @IBOutlet weak var playAgainLBL: UIButton!
        
        
        @IBOutlet weak var wordGuessLBL: UIButton!
        
     
        func updateUnderScore() {
            userGuessLabel.text = ""
            for i in wrd{
                //assigning _ for every letter in the word
                userGuessLabel.text! += "_ "
            }
            
        }
        
        
        
        }
    
    


