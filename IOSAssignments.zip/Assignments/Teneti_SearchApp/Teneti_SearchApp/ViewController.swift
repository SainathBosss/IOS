//
//  ViewController.swift
//  Teneti_SearchApp
//
//  Created by Teneti,Sainath R on 3/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var nextBtn: UIButton!
    
    @IBOutlet weak var resetBtn: UIButton!
    
    @IBOutlet weak var preBtn: UIButton!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    var imageNumber = 0
    var textNumber: Int = -1
    var count : Int = -1
    
    var arr = [["SuperMan", "BatMan", "WonderWomen", "GreenLanthern", "Flash"],
              ["SpiderMan", "IronMan", "CaptainAmerica", "Thor", "Hulk"],
              ["Prabhas", "MaheshBabu", "PavanKlayan", "Jr NTR", "RamCharan"]]
    var DC_Keywords = ["SuperMan", "Batman", "WonderWomen", "GreenLAntern", "Flash"]
    var Marvel_Keywords = ["SpiderMan", "IronMan", "CaptainAmerica", "Thor", "Hulk"]
    var TWood_Keywords = ["Prabhas", "MaheshBabu", "PavanKalyan", "Jr NTR", "RamCharan"]
    
    
    var topics_array = [["Superman is a superhero who appears in American comic books published by DC Comics. character was created by writer Jerry Siegel and artist Joe Shuster.", "Batman is a superhero appearing in American comic books published by DC Comics. The character was created by artist Bob Kane and writer Bill Finger.", "Wonder Woman is a superhero created by the American psychologist and writer William Moulton Marston and artist Harry G. Peter for DC Comics.", "Green Lantern is the name of several superheroes appearing in American comic books published by DC Comics.In this new timeline, Alan Scott is the modern-day Green Lantern for Earth 2.", "The Flash is an American superhero television series developed by Greg Berlanti, Andrew Kreisberg, and Geoff Johns, airing on The CW."],
        ["Spider-Man is a superhero appearing in American comic books published by Marvel Comics. Created by writer-editor Stan Lee and artist Steve Ditko.", "Iron Man is a superhero appearing in American comic books published by Marvel Comics. The character was co-created by writer and editor Stan Lee.", "Captain America is a superhero appearing in American comic books published by Marvel Comics. Created by cartoonists Joe Simon and Jack Kirby", "Thor (from Old Norse: Þórr) is a prominent god in Germanic paganism. In Norse mythology, he is a hammer-wielding god.", "The Hulk is a superhero appearing in American comic books published by Marvel Comics. Created by writer Stan Lee and artist Jack Kirby."],
        ["Uppalapati Venkata Suryanarayana Prabhas Raju, known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema.", "Ghattamaneni Mahesh Babu is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema.", "Pawan Kalyan is an Indian actor, filmmaker, and politician. His films are predominantly in Telugu cinema.", "Nandamuri Taraka Rama Rao Jr. (born 20 May 1983), also known as Jr NTR or Tarak, is an Indian actor who primarily works in Telugu cinema.", "Konidela Ram Charan Teja (born 27 March 1985) is an Indian actor, producer, and entrepreneur who primarily works in Telugu films."]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Welcome Page
        //Welcome Image
        resultImage.image = UIImage(named : "Welcome")
        //Next button
        nextBtn.isHidden = true
        //Previous button
        preBtn.isHidden = true
        //Reset Button
        resetBtn.isHidden = true
        searchBtn.isEnabled = false
    }

    @IBAction func searchTextBtn(_ sender: Any) {
        if(searchTextField.text!.isEmpty){
            searchBtn.isEnabled = false
                   preBtn.isHidden = true
                   nextBtn.isHidden = true
                   resetBtn.isHidden = true
               }
               else{
                   searchBtn.isEnabled = true
                 
               }
    }
    
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        //Increment Image and Text number
        imageNumber += 1
        resultImage.image = UIImage(named: arr[textNumber][imageNumber])
        topicInfoText.text = topics_array[textNumber][imageNumber]
        preBtn.isEnabled = true
        if(imageNumber == arr[textNumber].count-1){
        nextBtn.isEnabled = false
        
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        //Decrement Image and Text number
        nextBtn.isEnabled = true;
        imageNumber -= 1
        resultImage.image = UIImage(named: arr[textNumber][imageNumber])
        topicInfoText.text = topics_array[textNumber][imageNumber]
        if(imageNumber == 0){
        preBtn.isEnabled = false
        }
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        //
        nextBtn.isHidden = true
        preBtn.isHidden = true
        resetBtn.isHidden = true
        searchTextField.text = ""
        searchBtn.isEnabled = false
        topicInfoText.text = ""
        resultImage.image = UIImage(named: "Welcome")
    }
    
    
    @IBAction func searchButtonAction(_ sender: Any) {
        //When searched with key word should pop up the related image and text
            if(DC_Keywords.contains(searchTextField.text!)){
                textNumber = 0
                imageNumber = 0
                buttonsHidden()
            }
            else if(Marvel_Keywords.contains(searchTextField.text!)){
                textNumber = 1
                imageNumber = 0
                buttonsHidden()
            }
            else if(TWood_Keywords.contains(searchTextField.text!)){
                textNumber = 2
                imageNumber = 0;
                buttonsHidden()
            }
            else{
                textNumber = -1
                resultImage.image = UIImage(named: "Tryagain")
                resetBtn.isHidden = true
                nextBtn.isHidden = true
                preBtn.isHidden = true
            }
            
            if(textNumber != -1)
            {
                preBtn.isEnabled = false
                nextBtn.isEnabled = true
                count = arr[textNumber].count
                resultImage.image = UIImage(named: arr[textNumber][0])
                topicInfoText.text = topics_array[textNumber][0]
            }
        
            
        func buttonsHidden(){
            nextBtn.isHidden = false
            preBtn.isHidden = false
            resetBtn.isHidden = false
                    }
    }
}

