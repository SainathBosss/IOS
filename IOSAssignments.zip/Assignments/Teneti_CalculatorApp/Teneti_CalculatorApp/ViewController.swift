//
//  ViewController.swift
//  Teneti_CalculatorApp
//
//  Created by Teneti,Sainath R on 2/12/23.
//

import UIKit

class ViewController: UIViewController {

    var currentNumber = 0.0
    var previousNumber = 0.0

        var op = " "

    @IBOutlet weak var resultOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        resultOutlet.text = ""
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonZero(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "0"
    }
    @IBAction func buttonOne(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "1"
        }
    @IBAction func buttonTwo(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "2"
        }
    @IBAction func buttonThree(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "3"
        }
    @IBAction func buttonFour(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "4"
        }
    @IBAction func buttonFive(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "5"
        }
    @IBAction func buttonSix(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "6"
        }
    @IBAction func buttonSeven(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "7"
        }
    @IBAction func buttonEight(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "8"
    }
    @IBAction func buttonNine(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "9"
        }
    @IBAction func buttonDot(_ sender: UIButton) {
        let res = resultOutlet.text!
        resultOutlet.text = res + "."
        }
    @IBAction func buttonAC(_ sender: UIButton) {
        currentNumber = 0.0
        previousNumber = 0.0
        op = " "
            resultOutlet.text = ""
    }
    @IBAction func buttonC(_ sender: UIButton) {
        var cc = resultOutlet.text!
        cc.removeLast()
        resultOutlet.text = cc
    }
    @IBAction func buttonSignChange(_ sender: UIButton) {
        //Changing the sign of the number
        let varbl = resultOutlet.text!
        if op == "-" {
            op = "+"
        resultOutlet.text = "-" + varbl
        }
        else if op == "+"{
            op = "-"
            resultOutlet.text = "-" + varbl
        }
        }
    
    @IBAction func buttonDevide(_ sender: UIButton) {
        op = "/"
        currentNumber = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = ""
    }
    @IBAction func buttonMultiply(_ sender: UIButton) {
        op = "*"
        currentNumber =  Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = ""
    }
    @IBAction func buttonMinus(_ sender: UIButton) {
        op = "-"
        currentNumber =  Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = ""
    }
    @IBAction func buttonPlus(_ sender: UIButton) {
        op = "+"
        currentNumber =  Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = ""
    }
    @IBAction func buttonPercent(_ sender: UIButton) {
        op = "%"
        currentNumber =  Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = ""
    }
    @IBAction func buttonEquals(_ sender: UIButton) {
        if(resultOutlet.text!.contains("-")){
            resultOutlet.text!.removeFirst()
            previousNumber = Double(resultOutlet.text!) ?? 0.0
        }
        else{
        previousNumber =  Double(resultOutlet.text!) ?? 0.0
        }
        let firstNumber = Double(currentNumber)
            let secondNumber = Double(previousNumber)
           var result = 0.0
            switch op {
            case "+":
                result = firstNumber + secondNumber
                resultOutlet.text = "\(Int(result))"
            case "-":
                result = firstNumber - secondNumber
                resultOutlet.text = "\(Int(result))"
            case "*":
                result = firstNumber * secondNumber
                resultOutlet.text = "\(Int(result))"
            case "/":
                if previousNumber == 0.0 {
                    resultOutlet.text = "Not a number"
                }
                else{
                    result = firstNumber / secondNumber
                    result = round(result * 100000) / 100000.0
                    resultOutlet.text = "\(result)"
                }
            case "%":
                if(resultOutlet.text!.contains(".")){
                    result = firstNumber.truncatingRemainder(dividingBy: secondNumber)
                    result = round(result * 100000) / 100000.0
                    resultOutlet.text = "\(result)"
                }
                else{
                    result = Double(Int(firstNumber) % Int(secondNumber))
                    resultOutlet.text = "\(Int(result))"
                }
            default :
                resultOutlet.text = ""
            }
       
        
    }

  

}
